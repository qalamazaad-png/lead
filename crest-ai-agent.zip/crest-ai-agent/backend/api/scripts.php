<?php
require_once __DIR__ . '/../config/config.php';
$db     = getDB();
$leadId = (int)($_GET['lead_id'] ?? 0);
$channel = $_GET['channel'] ?? 'email';
$type    = $_GET['type'] ?? 'email1';
if (!$leadId) jsonError('lead_id required');
$stmt = $db->prepare("SELECT * FROM scripts WHERE lead_id=? AND channel=? AND email_type=? ORDER BY version DESC LIMIT 1");
$stmt->execute([$leadId, $channel, $type]);
$script = $stmt->fetch();
jsonResponse(true, $script ?: null);
