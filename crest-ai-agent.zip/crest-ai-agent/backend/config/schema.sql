-- ===== CREST AI AGENT — DATABASE SCHEMA =====
-- Run: mysql -u root -p crest_agent < schema.sql

CREATE DATABASE IF NOT EXISTS crest_agent CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE crest_agent;

-- ─── Leads ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS leads (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_name        VARCHAR(255) NOT NULL,
    company_website     VARCHAR(500) DEFAULT NULL,
    linkedin_page       VARCHAR(500) DEFAULT NULL,
    industry            VARCHAR(255) DEFAULT NULL,
    products            TEXT         DEFAULT NULL,
    country             VARCHAR(100) DEFAULT NULL,
    contact_person      VARCHAR(255) DEFAULT NULL,
    job_profile         VARCHAR(255) DEFAULT NULL,
    linkedin_profile    VARCHAR(500) DEFAULT NULL,
    email_a             VARCHAR(255) DEFAULT NULL,
    email_b             VARCHAR(255) DEFAULT NULL,
    contact_a           VARCHAR(50)  DEFAULT NULL,
    contact_b           VARCHAR(50)  DEFAULT NULL,
    whatsapp_link       VARCHAR(500) DEFAULT NULL,
    skype_id            VARCHAR(255) DEFAULT NULL,
    status              ENUM('new','contacted','replied','qualified','meeting','closed') DEFAULT 'new',
    scraped_summary     TEXT         DEFAULT NULL,
    scraped_at          DATETIME     DEFAULT NULL,
    campaign_id         INT UNSIGNED DEFAULT NULL,
    source_file         VARCHAR(255) DEFAULT NULL,
    created_at          DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status    (status),
    INDEX idx_country   (country),
    INDEX idx_email_a   (email_a),
    INDEX idx_campaign  (campaign_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Campaigns ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS campaigns (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(255) NOT NULL,
    description TEXT         DEFAULT NULL,
    status      ENUM('draft','active','paused','completed') DEFAULT 'active',
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Scripts ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS scripts (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lead_id     INT UNSIGNED NOT NULL,
    channel     ENUM('email','whatsapp','linkedin','skype') NOT NULL,
    email_type  ENUM('email1','followup','email2','email3') DEFAULT 'email1',
    subject     VARCHAR(500) DEFAULT NULL,
    content     TEXT NOT NULL,
    version     TINYINT UNSIGNED DEFAULT 1,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_lead_channel_type (lead_id, channel, email_type),
    INDEX idx_lead (lead_id),
    FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Outreach Log ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS outreach_log (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lead_id         INT UNSIGNED NOT NULL,
    channel         ENUM('email','whatsapp','linkedin','skype') NOT NULL,
    email_type      VARCHAR(50) DEFAULT 'email1',
    direction       ENUM('sent','received') DEFAULT 'sent',
    status          ENUM('queued','sent','delivered','opened','clicked','replied','failed') DEFAULT 'queued',
    subject         VARCHAR(500) DEFAULT NULL,
    content         TEXT DEFAULT NULL,
    external_id     VARCHAR(255) DEFAULT NULL,
    error_message   TEXT DEFAULT NULL,
    sent_at         DATETIME DEFAULT NULL,
    replied_at      DATETIME DEFAULT NULL,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_lead      (lead_id),
    INDEX idx_channel   (channel),
    INDEX idx_status    (status),
    FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Settings ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS settings (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `key`       VARCHAR(100) NOT NULL UNIQUE,
    value       TEXT DEFAULT NULL,
    updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default settings
INSERT IGNORE INTO settings (`key`, value) VALUES
('from_name',           'Crest Speciality Resins'),
('from_email',          'enquiry@crestresins.com'),
('reply_to',            'enquiry@crestresins.com'),
('followup_days',       '6'),
('calendly_link',       ''),
('company_description', 'Crest Speciality Resins is a leading Indian manufacturer of specialty resins for composites and coatings, with 30+ years of experience.'),
('company_usps',        '30+ years expertise\nTailor-made resins\nISO certified\nInternational presence'),
('claude_api_key',      ''),
('openai_api_key',      ''),
('apify_token',         ''),
('lusha_api_key',       ''),
('wa_api_key',          ''),
('zoho_client_id',      ''),
('zoho_client_secret',  ''),
('zoho_access_token',   ''),
('zoho_refresh_token',  '');

-- ─── Activity Log ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS activity_log (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    type        VARCHAR(50) NOT NULL,
    message     TEXT NOT NULL,
    lead_id     INT UNSIGNED DEFAULT NULL,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created (created_at),
    INDEX idx_lead    (lead_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
