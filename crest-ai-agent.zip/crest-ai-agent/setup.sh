#!/bin/bash
# ===== CREST AI AGENT — VPS SETUP SCRIPT =====
# Run as root on a fresh Ubuntu 22.04 / 24.04 VPS
# Usage: bash setup.sh yourdomain.com

set -e
DOMAIN=${1:-yourdomain.com}
APP_DIR=/var/www/crest-agent
DB_NAME=crest_agent
DB_USER=crest_user
DB_PASS=$(openssl rand -base64 24 | tr -d '=+/' | head -c 24)
PHP_VER=8.2

echo "====================================================="
echo "  Crest AI Agent — VPS Setup"
echo "  Domain: $DOMAIN"
echo "  App Dir: $APP_DIR"
echo "====================================================="

# ─── System update ────────────────────────────────────────────
echo "[1/9] Updating system..."
apt-get update -qq && apt-get upgrade -y -qq

# ─── Install packages ─────────────────────────────────────────
echo "[2/9] Installing Nginx, PHP, MySQL, Composer..."
apt-get install -y -qq nginx mysql-server \
  php${PHP_VER} php${PHP_VER}-fpm php${PHP_VER}-mysql php${PHP_VER}-curl \
  php${PHP_VER}-mbstring php${PHP_VER}-xml php${PHP_VER}-zip php${PHP_VER}-intl \
  php${PHP_VER}-gd php${PHP_VER}-bcmath \
  certbot python3-certbot-nginx \
  unzip curl git cron

# ─── MySQL setup ──────────────────────────────────────────────
echo "[3/9] Setting up MySQL database..."
mysql -e "CREATE DATABASE IF NOT EXISTS ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -e "CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';"
mysql -e "GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost';"
mysql -e "FLUSH PRIVILEGES;"

# ─── App directory ────────────────────────────────────────────
echo "[4/9] Setting up app directory..."
mkdir -p $APP_DIR
mkdir -p $APP_DIR/uploads
mkdir -p $APP_DIR/logs

# Copy files (assumes script runs from project root)
if [ -d "./frontend" ]; then
  cp -r ./frontend $APP_DIR/
  cp -r ./backend  $APP_DIR/
  cp -r ./nginx    $APP_DIR/
  cp composer.json $APP_DIR/
fi

# Write .env
cat > $APP_DIR/.env <<EOF
APP_URL=https://${DOMAIN}
APP_ENV=production
DB_HOST=localhost
DB_NAME=${DB_NAME}
DB_USER=${DB_USER}
DB_PASS=${DB_PASS}
EOF

# ─── PHP config ───────────────────────────────────────────────
echo "[5/9] Configuring PHP..."
cat > /etc/php/${PHP_VER}/fpm/conf.d/99-crest.ini <<EOF
upload_max_filesize = 15M
post_max_size = 16M
max_execution_time = 120
memory_limit = 256M
display_errors = Off
log_errors = On
error_log = /var/log/php-crest.log
EOF
systemctl restart php${PHP_VER}-fpm

# ─── Composer ─────────────────────────────────────────────────
echo "[6/9] Installing PHP dependencies..."
curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
cd $APP_DIR && composer install --no-dev --optimize-autoloader --quiet

# ─── Database schema ──────────────────────────────────────────
echo "[7/9] Creating database schema..."
mysql -u $DB_USER -p$DB_PASS $DB_NAME < $APP_DIR/backend/config/schema.sql

# ─── Nginx ────────────────────────────────────────────────────
echo "[8/9] Configuring Nginx..."
sed "s/yourdomain.com/$DOMAIN/g" $APP_DIR/nginx/crest-agent.conf > /etc/nginx/sites-available/crest-agent
ln -sf /etc/nginx/sites-available/crest-agent /etc/nginx/sites-enabled/crest-agent
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

# ─── SSL ──────────────────────────────────────────────────────
echo "[8b] Obtaining SSL certificate..."
certbot --nginx -d $DOMAIN -d www.$DOMAIN --non-interactive --agree-tos --email admin@$DOMAIN || \
  echo "  SSL setup skipped (point DNS to this server first, then run: certbot --nginx -d $DOMAIN)"

# ─── Permissions ──────────────────────────────────────────────
chown -R www-data:www-data $APP_DIR
chmod -R 755 $APP_DIR
chmod -R 775 $APP_DIR/uploads
chmod -R 775 $APP_DIR/logs
chmod 600 $APP_DIR/.env

# ─── Cron jobs ────────────────────────────────────────────────
echo "[9/9] Setting up cron jobs..."
(crontab -l 2>/dev/null; echo "# Crest AI Agent jobs") | crontab -
(crontab -l 2>/dev/null; echo "0 9 * * *      php $APP_DIR/backend/jobs/followup.php >> $APP_DIR/logs/followup.log 2>&1") | crontab -
(crontab -l 2>/dev/null; echo "*/30 * * * *   php $APP_DIR/backend/jobs/reply-analyser.php >> $APP_DIR/logs/replies.log 2>&1") | crontab -
(crontab -l 2>/dev/null; echo "*/5 * * * *    php $APP_DIR/backend/jobs/scraper.php >> $APP_DIR/logs/scraper.log 2>&1") | crontab -
systemctl enable cron

# ─── UFW Firewall ─────────────────────────────────────────────
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable

echo ""
echo "====================================================="
echo "  SETUP COMPLETE!"
echo "====================================================="
echo "  App URL:     https://$DOMAIN"
echo "  App Dir:     $APP_DIR"
echo "  DB Name:     $DB_NAME"
echo "  DB User:     $DB_USER"
echo "  DB Password: $DB_PASS  ← SAVE THIS!"
echo ""
echo "  NEXT STEPS:"
echo "  1. Open https://$DOMAIN → Settings"
echo "  2. Enter your Claude API key, Zoho credentials,"
echo "     WhatsApp API key, Apify token"
echo "  3. Upload your first leads Excel file"
echo "====================================================="
