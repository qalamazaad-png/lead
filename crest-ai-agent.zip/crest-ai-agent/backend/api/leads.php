<?php
require_once __DIR__ . '/../config/config.php';

$method = $_SERVER['REQUEST_METHOD'];
$db = getDB();

if ($method === 'GET') {
    $id      = isset($_GET['id']) ? (int)$_GET['id'] : null;
    $fields  = isset($_GET['fields']) ? $_GET['fields'] : null;
    $limit   = min((int)($_GET['limit'] ?? 500), 1000);
    $offset  = (int)($_GET['offset'] ?? 0);
    $status  = $_GET['status'] ?? '';
    $country = $_GET['country'] ?? '';
    $search  = $_GET['q'] ?? '';

    $cols = $fields ? implode(',', array_map(fn($f) => '`'.preg_replace('/[^a-z_]/','',$f).'`', explode(',', $fields))) : '*';
    $where = ['1=1'];
    $params = [];

    if ($id) { $where[] = 'id = ?'; $params[] = $id; }
    if ($status) { $where[] = 'status = ?'; $params[] = $status; }
    if ($country) { $where[] = 'country = ?'; $params[] = $country; }
    if ($search) {
        $where[] = '(company_name LIKE ? OR contact_person LIKE ? OR email_a LIKE ? OR country LIKE ?)';
        $s = '%' . $search . '%';
        array_push($params, $s, $s, $s, $s);
    }

    $sql = "SELECT {$cols} FROM leads WHERE " . implode(' AND ', $where) . " ORDER BY created_at DESC LIMIT ? OFFSET ?";
    $params[] = $limit; $params[] = $offset;

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $leads = $stmt->fetchAll();

    $countStmt = $db->prepare("SELECT COUNT(*) FROM leads WHERE " . implode(' AND ', array_slice($where, 0)));
    $countStmt->execute(array_slice($params, 0, -2));
    $total = $countStmt->fetchColumn();

    jsonResponse(true, $leads, '', 200);
}

if ($method === 'PUT') {
    $body = getRequestBody();
    $id = (int)($body['id'] ?? 0);
    if (!$id) jsonError('Lead ID required');

    $allowed = ['status','scraped_summary','contact_person','job_profile','email_a','email_b','whatsapp_link','skype_id','linkedin_profile'];
    $sets = []; $params = [];
    foreach ($allowed as $field) {
        if (isset($body[$field])) { $sets[] = "`{$field}` = ?"; $params[] = $body[$field]; }
    }
    if (!$sets) jsonError('No valid fields to update');
    $params[] = $id;
    $db->prepare("UPDATE leads SET " . implode(',', $sets) . " WHERE id = ?")->execute($params);
    jsonResponse(true, null, 'Lead updated');
}

if ($method === 'DELETE') {
    $body = getRequestBody();
    $id = (int)($body['id'] ?? 0);
    if (!$id) jsonError('Lead ID required');
    $db->prepare("DELETE FROM leads WHERE id = ?")->execute([$id]);
    jsonResponse(true, null, 'Lead deleted');
}

jsonError('Method not allowed', 405);
