<?php
// ===== REPLY ANALYSER JOB =====
// Run every 30min: */30 * * * * php /var/www/crest-agent/backend/jobs/reply-analyser.php

require_once __DIR__ . '/../config/config.php';

$db        = getDB();
$claudeKey = getSetting('claude_api_key') ?: CLAUDE_API_KEY;
if (!$claudeKey) { echo "Claude API key not configured\n"; exit; }

// Fetch recent emails from Zoho Mail API
$accessToken = getSetting('zoho_access_token');
if (!$accessToken) { echo "Zoho not connected\n"; exit; }

$emails = fetchZohoReplies($accessToken);
echo "Fetched " . count($emails) . " emails to analyse\n";

foreach ($emails as $email) {
    $from    = $email['from'] ?? '';
    $subject = $email['subject'] ?? '';
    $body    = $email['body'] ?? '';

    // Match to lead by email address
    $stmt = $db->prepare("SELECT * FROM leads WHERE email_a = ? OR email_b = ? LIMIT 1");
    $stmt->execute([$from, $from]);
    $lead = $stmt->fetch();
    if (!$lead) { echo "  No lead found for: {$from}\n"; continue; }

    echo "  Analysing reply from: {$lead['company_name']}\n";

    // Classify intent with Claude
    $intent = classifyReplyIntent($body, $claudeKey);
    echo "  Intent: {$intent}\n";

    // Log inbound
    $db->prepare("INSERT INTO outreach_log (lead_id, channel, direction, status, subject, content) VALUES (?,'email','received','replied',?,?)")
       ->execute([$lead['id'], $subject, substr($body, 0, 2000)]);

    // Update lead status
    $db->prepare("UPDATE leads SET status = 'replied' WHERE id = ?")->execute([$lead['id']]);
    $db->prepare("INSERT INTO activity_log (type, message, lead_id) VALUES ('reply', ?, ?)")
       ->execute(["Reply received from {$lead['company_name']} — intent: {$intent}", $lead['id']]);

    // Trigger next action based on intent
    if ($intent === 'interested') {
        // Send Email 2 — ask for technical requirements
        triggerEmail($lead['id'], 'email2');
        $db->prepare("UPDATE leads SET status = 'qualified' WHERE id = ?")->execute([$lead['id']]);
        $db->prepare("INSERT INTO activity_log (type, message, lead_id) VALUES ('email', ?, ?)")
           ->execute(["Email 2 (technical questions) sent to {$lead['company_name']}", $lead['id']]);
    } elseif ($intent === 'technical_sent') {
        // They've sent specs — send Email 3 with meeting invite
        triggerEmail($lead['id'], 'email3');
        $db->prepare("UPDATE leads SET status = 'meeting' WHERE id = ?")->execute([$lead['id']]);
    } elseif ($intent === 'not_interested') {
        $db->prepare("UPDATE leads SET status = 'closed' WHERE id = ?")->execute([$lead['id']]);
    }
    // 'unclear' — flag for manual review, no auto-action
}

echo "Done\n";

// ─── Fetch Zoho inbox ──────────────────────────────────────────
function fetchZohoReplies(string $token): array {
    $ch = curl_init('https://mail.zoho.in/api/accounts/emails?limit=20&sortOrder=desc&folderId=INBOX');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Authorization: Zoho-oauthtoken ' . $token],
        CURLOPT_TIMEOUT        => 20,
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code !== 200) return [];
    $data = json_decode($res, true);
    $emails = [];
    foreach ($data['data'] ?? [] as $msg) {
        if (isset($msg['sender']) && isset($msg['subject'])) {
            $emails[] = [
                'from'    => $msg['sender']['mailAddress'] ?? '',
                'subject' => $msg['subject'] ?? '',
                'body'    => $msg['content'] ?? $msg['summary'] ?? '',
            ];
        }
    }
    return $emails;
}

// ─── Classify Intent ───────────────────────────────────────────
function classifyReplyIntent(string $body, string $apiKey): string {
    $prompt = "Classify this email reply from a B2B lead into ONE of these categories:
- interested: they want to know more, want to connect, asking about products
- technical_sent: they have sent their technical requirements or specifications
- not_interested: they declined, said no, unsubscribed
- unclear: ambiguous, auto-reply, spam, or not clearly one of the above

Reply text:
\"\"\"
" . substr($body, 0, 1000) . "
\"\"\"

Respond with ONLY the category word, nothing else.";

    $payload = ['model'=>'claude-sonnet-4-20250514','max_tokens'=>10,'messages'=>[['role'=>'user','content'=>$prompt]]];
    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json','x-api-key: '.$apiKey,'anthropic-version: 2023-06-01'],
        CURLOPT_TIMEOUT        => 15,
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($res, true);
    $raw  = strtolower(trim($data['content'][0]['text'] ?? 'unclear'));
    return in_array($raw, ['interested','technical_sent','not_interested','unclear']) ? $raw : 'unclear';
}

// ─── Trigger email ─────────────────────────────────────────────
function triggerEmail(int $leadId, string $type): void {
    $ch = curl_init(APP_URL . '/api/outreach.php');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode(['lead_ids'=>[$leadId],'channel'=>'email','type'=>$type]),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT        => 45,
    ]);
    curl_exec($ch);
    curl_close($ch);
}
