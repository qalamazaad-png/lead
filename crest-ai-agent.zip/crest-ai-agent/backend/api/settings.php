<?php
require_once __DIR__ . '/../config/config.php';
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $db->query("SELECT `key`, value FROM settings");
    $rows = $stmt->fetchAll();
    $settings = [];
    // Never expose API keys to frontend
    $sensitive = ['claude_api_key','openai_api_key','apify_token','lusha_api_key','wa_api_key','zoho_client_secret','zoho_access_token','zoho_refresh_token','zoho_smtp_password'];
    foreach ($rows as $r) {
        $settings[$r['key']] = in_array($r['key'], $sensitive) ? (empty($r['value']) ? '' : '••••••••') : $r['value'];
    }
    jsonResponse(true, $settings);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = getRequestBody();
    $allowed = [
        'from_name','from_email','reply_to','followup_days','calendly_link',
        'company_description','company_usps',
        'claude_api_key','openai_api_key','apify_token','lusha_api_key',
        'wa_api_key','zoho_client_id','zoho_client_secret','zoho_smtp_password',
    ];
    $stmt = $db->prepare("INSERT INTO settings (`key`, value) VALUES (?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)");
    $saved = 0;
    foreach ($allowed as $key) {
        if (isset($body[$key]) && $body[$key] !== '' && $body[$key] !== '••••••••') {
            $stmt->execute([$key, $body[$key]]);
            $saved++;
        }
    }
    $db->prepare("INSERT INTO activity_log (type, message) VALUES ('settings', ?)")->execute(["Settings updated ({$saved} fields)"]);
    jsonResponse(true, null, 'Settings saved');
}

jsonError('Method not allowed', 405);
