<?php
require_once __DIR__ . '/../config/config.php';
$db = getDB();
$limit = min((int)($_GET['limit'] ?? 20), 100);
$stmt = $db->prepare("SELECT id, type, message, lead_id, created_at FROM activity_log ORDER BY created_at DESC LIMIT ?");
$stmt->execute([$limit]);
jsonResponse(true, $stmt->fetchAll());
