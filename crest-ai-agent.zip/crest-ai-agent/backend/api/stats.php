<?php
// ===== stats.php — Dashboard stats =====
require_once __DIR__ . '/../config/config.php';
$db = getDB();
$total    = $db->query("SELECT COUNT(*) FROM leads")->fetchColumn();
$emails   = $db->query("SELECT COUNT(*) FROM outreach_log WHERE channel='email' AND status IN ('sent','delivered','opened')")->fetchColumn();
$replied  = $db->query("SELECT COUNT(*) FROM leads WHERE status IN ('replied','qualified','meeting')")->fetchColumn();
$meetings = $db->query("SELECT COUNT(*) FROM leads WHERE status='meeting'")->fetchColumn();
$channels = [
    'email'    => (int)$db->query("SELECT COUNT(*) FROM outreach_log WHERE channel='email'")->fetchColumn(),
    'whatsapp' => (int)$db->query("SELECT COUNT(*) FROM outreach_log WHERE channel='whatsapp'")->fetchColumn(),
    'linkedin' => (int)$db->query("SELECT COUNT(*) FROM outreach_log WHERE channel='linkedin'")->fetchColumn(),
    'skype'    => (int)$db->query("SELECT COUNT(*) FROM outreach_log WHERE channel='skype'")->fetchColumn(),
];
jsonResponse(true, compact('total','emails','replied','meetings','channels'));
