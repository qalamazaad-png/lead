/* ===== CREST AI AGENT — FRONTEND APP ===== */
const API = '/api';

// ─── Navigation ────────────────────────────────────────────────
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', e => {
    e.preventDefault();
    showPage(item.dataset.page);
  });
});

function showPage(name) {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.page === name));
  document.querySelectorAll('.page').forEach(p => p.classList.toggle('active', p.id === 'page-' + name));
  document.getElementById('page-title').textContent = name.charAt(0).toUpperCase() + name.slice(1);
  if (name === 'dashboard') loadDashboard();
  if (name === 'leads') loadLeads();
  if (name === 'campaigns') loadCampaigns();
  if (name === 'scripts') loadScriptLeadList();
}

// ─── Date ───────────────────────────────────────────────────────
document.getElementById('current-date').textContent = new Date().toLocaleDateString('en-IN', {weekday:'long', year:'numeric', month:'long', day:'numeric'});

// ─── Dashboard ─────────────────────────────────────────────────
async function loadDashboard() {
  try {
    const res = await fetch(`${API}/stats.php`);
    const d = await res.json();
    if (d.success) {
      animateCount('stat-total', d.data.total || 0);
      animateCount('stat-emails', d.data.emails_sent || 0);
      animateCount('stat-replied', d.data.replied || 0);
      animateCount('stat-meetings', d.data.meetings || 0);
      renderChannelBars(d.data.channels || {});
    }
    loadActivity();
  } catch(e) { console.error(e); }
}

function animateCount(id, target) {
  const el = document.getElementById(id);
  let current = 0; const step = Math.max(1, Math.floor(target / 30));
  const timer = setInterval(() => {
    current = Math.min(current + step, target);
    el.textContent = current.toLocaleString();
    if (current >= target) clearInterval(timer);
  }, 40);
}

function renderChannelBars(ch) {
  const max = Math.max(1, ch.email || 0, ch.whatsapp || 0, ch.linkedin || 0, ch.skype || 0);
  const set = (id, barId, val) => {
    document.getElementById(id).textContent = val;
    setTimeout(() => { document.getElementById(barId).style.width = ((val/max)*100) + '%'; }, 100);
  };
  set('cnt-email','bar-email', ch.email||0);
  set('cnt-wa','bar-wa', ch.whatsapp||0);
  set('cnt-li','bar-li', ch.linkedin||0);
  set('cnt-sk','bar-sk', ch.skype||0);
}

async function loadActivity() {
  try {
    const res = await fetch(`${API}/activity.php?limit=20`);
    const d = await res.json();
    const feed = document.getElementById('activity-feed');
    if (!d.success || !d.data.length) { feed.innerHTML = '<div class="activity-empty">No activity yet</div>'; return; }
    feed.innerHTML = d.data.map(a => `
      <div class="activity-item">
        <div class="activity-dot ${a.type}"></div>
        <div class="activity-content">
          <div class="activity-text">${escHtml(a.message)}</div>
          <div class="activity-time">${timeAgo(a.created_at)}</div>
        </div>
      </div>`).join('');
  } catch(e) {}
}

function refreshStats() { loadDashboard(); showToast('Stats refreshed', 'info'); }

// ─── Leads ─────────────────────────────────────────────────────
let allLeads = [], selectedLeads = new Set();

async function loadLeads() {
  try {
    const res = await fetch(`${API}/leads.php`);
    const d = await res.json();
    if (d.success) { allLeads = d.data; renderLeads(allLeads); }
  } catch(e) { document.getElementById('leads-tbody').innerHTML = '<tr><td colspan="8" class="table-empty">Error loading leads</td></tr>'; }
}

function renderLeads(leads) {
  const tbody = document.getElementById('leads-tbody');
  if (!leads.length) { tbody.innerHTML = '<tr><td colspan="8" class="table-empty">No leads found</td></tr>'; return; }
  tbody.innerHTML = leads.map(l => `
    <tr data-id="${l.id}" class="${selectedLeads.has(l.id)?'selected':''}">
      <td><input type="checkbox" ${selectedLeads.has(l.id)?'checked':''} onchange="toggleSelect('${l.id}',this)"/></td>
      <td><strong>${escHtml(l.company_name||'—')}</strong><br/><span style="color:var(--text-muted);font-size:11px">${escHtml(l.country||'')}</span></td>
      <td>${escHtml(l.contact_person||'—')}<br/><span style="color:var(--text-muted);font-size:11px">${escHtml(l.job_profile||'')}</span></td>
      <td>${escHtml(l.country||'—')}</td>
      <td style="max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHtml(l.industry||'—')}</td>
      <td><span class="status-pill ${l.status||'new'}">${capitalize(l.status||'new')}</span></td>
      <td><div class="ch-icons">
        <div class="ch-icon email ${l.email_a?'':'inactive'}" title="Email">E</div>
        <div class="ch-icon wa ${l.whatsapp_link?'':'inactive'}" title="WhatsApp">W</div>
        <div class="ch-icon li ${l.linkedin_profile?'':'inactive'}" title="LinkedIn">L</div>
        <div class="ch-icon sk ${l.skype_id?'':'inactive'}" title="Skype">S</div>
      </div></td>
      <td>
        <button class="action-btn" onclick="openLeadModal(${l.id})" title="View">
          <svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
        </button>
        <button class="action-btn" onclick="generateScript(${l.id})" title="Generate Script">
          <svg viewBox="0 0 24 24"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
        </button>
        <button class="action-btn" onclick="quickSend(${l.id},'email')" title="Send Email">
          <svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
        </button>
      </td>
    </tr>`).join('');
}

function searchLeads(q) {
  q = q.toLowerCase();
  renderLeads(allLeads.filter(l =>
    (l.company_name||'').toLowerCase().includes(q) ||
    (l.contact_person||'').toLowerCase().includes(q) ||
    (l.country||'').toLowerCase().includes(q) ||
    (l.industry||'').toLowerCase().includes(q)
  ));
}

function filterLeads() {
  const status = document.getElementById('status-filter').value;
  const channel = document.getElementById('channel-filter').value;
  renderLeads(allLeads.filter(l => {
    const sOk = !status || l.status === status;
    const cOk = !channel ||
      (channel==='email' && l.email_a) ||
      (channel==='whatsapp' && l.whatsapp_link) ||
      (channel==='linkedin' && l.linkedin_profile) ||
      (channel==='skype' && l.skype_id);
    return sOk && cOk;
  }));
}

function toggleSelect(id, cb) {
  if (cb.checked) selectedLeads.add(id); else selectedLeads.delete(id);
  document.querySelectorAll('#leads-tbody tr').forEach(r => r.classList.toggle('selected', selectedLeads.has(r.dataset.id)));
  const ba = document.getElementById('bulk-actions');
  ba.style.display = selectedLeads.size ? 'flex' : 'none';
  document.getElementById('bulk-count').textContent = selectedLeads.size + ' selected';
}

function selectAllLeads(cb) {
  allLeads.forEach(l => { if(cb.checked) selectedLeads.add(String(l.id)); else selectedLeads.delete(String(l.id)); });
  renderLeads(allLeads);
  document.getElementById('bulk-actions').style.display = selectedLeads.size ? 'flex' : 'none';
  document.getElementById('bulk-count').textContent = selectedLeads.size + ' selected';
}

async function bulkOutreach(channel) {
  if (!selectedLeads.size) return;
  try {
    const res = await fetch(`${API}/outreach.php`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ lead_ids: Array.from(selectedLeads), channel })
    });
    const d = await res.json();
    showToast(d.message || `${channel} outreach queued for ${selectedLeads.size} leads`, 'success');
    selectedLeads.clear();
    document.getElementById('bulk-actions').style.display = 'none';
    document.getElementById('select-all').checked = false;
    loadLeads();
  } catch(e) { showToast('Error sending outreach', 'error'); }
}

// ─── Lead Modal ─────────────────────────────────────────────────
async function openLeadModal(id) {
  const lead = allLeads.find(l => l.id == id);
  if (!lead) return;
  document.getElementById('modal-company').textContent = lead.company_name || 'Lead';
  const fields = [
    ['Company',lead.company_name],['Website',lead.company_website],
    ['Industry',lead.industry],['Products',lead.products],
    ['Country',lead.country],['Contact',lead.contact_person],
    ['Job Profile',lead.job_profile],['Email A',lead.email_a],
    ['Email B',lead.email_b],['WhatsApp',lead.whatsapp_link],
    ['LinkedIn',lead.linkedin_profile],['Status',lead.status],
  ];
  document.getElementById('modal-body').innerHTML = `
    <div class="modal-field" style="grid-template-columns:130px 1fr;row-gap:6px">
    ${fields.map(([k,v])=>v?`<span class="modal-label">${k}</span><span class="modal-value">${escHtml(String(v))}</span>`:'').join('')}
    </div>
    ${lead.scraped_summary?`<div style="margin-top:16px;padding:12px;background:var(--bg-3);border-radius:8px;font-size:12px;color:var(--text-secondary)"><strong style="color:var(--teal)">Scraped Intelligence</strong><br/>${escHtml(lead.scraped_summary)}</div>`:''}
  `;
  document.getElementById('lead-modal').classList.add('open');
  document.getElementById('lead-modal').dataset.leadId = id;
}

function closeLeadModal() { document.getElementById('lead-modal').classList.remove('open'); }
function closeModal(e) { if (e.target === e.currentTarget) closeLeadModal(); }

async function generateAndSend() {
  const id = document.getElementById('lead-modal').dataset.leadId;
  closeLeadModal();
  showPage('scripts');
  const sel = document.getElementById('script-lead-select');
  if (sel) { sel.value = id; loadScript(); }
}

// ─── Upload ─────────────────────────────────────────────────────
function handleFileSelect(input) {
  const file = input.files[0];
  if (!file) return;
  document.getElementById('column-map').style.display = 'block';
  document.getElementById('column-preview').textContent = `File: ${file.name} (${(file.size/1024).toFixed(1)} KB) — ready to import`;
}

const zone = document.getElementById('upload-zone');
if (zone) {
  zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('drag-over'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
  zone.addEventListener('drop', e => {
    e.preventDefault(); zone.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file) {
      document.getElementById('excel-file').files = e.dataTransfer.files;
      handleFileSelect({ files: [file] });
    }
  });
}

async function importLeads() {
  const fileInput = document.getElementById('excel-file');
  if (!fileInput.files[0]) { showToast('Please select a file first', 'error'); return; }
  const formData = new FormData();
  formData.append('file', fileInput.files[0]);
  formData.append('scrape', document.getElementById('opt-scrape').checked ? '1' : '0');
  formData.append('generate', document.getElementById('opt-generate').checked ? '1' : '0');
  formData.append('autostart', document.getElementById('opt-autostart').checked ? '1' : '0');

  document.getElementById('upload-progress').style.display = 'block';
  document.getElementById('import-btn').disabled = true;

  try {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `${API}/import.php`);
    xhr.upload.onprogress = e => {
      const pct = Math.round((e.loaded/e.total)*80);
      document.getElementById('progress-fill').style.width = pct + '%';
      document.getElementById('progress-text').textContent = `Uploading... ${pct}%`;
    };
    xhr.onload = () => {
      const d = JSON.parse(xhr.responseText);
      document.getElementById('progress-fill').style.width = '100%';
      document.getElementById('progress-text').textContent = d.message || 'Import complete';
      if (d.success) { showToast(`✓ Imported ${d.count} leads`, 'success'); setTimeout(()=>showPage('leads'), 1500); }
      else { showToast(d.error || 'Import failed', 'error'); }
      document.getElementById('import-btn').disabled = false;
    };
    xhr.onerror = () => { showToast('Network error', 'error'); document.getElementById('import-btn').disabled = false; };
    xhr.send(formData);
  } catch(e) { showToast('Error uploading file', 'error'); document.getElementById('import-btn').disabled = false; }
}

// ─── Scripts ────────────────────────────────────────────────────
let currentChannel = 'email', currentLeadId = null;

async function loadScriptLeadList() {
  try {
    const res = await fetch(`${API}/leads.php?fields=id,company_name`);
    const d = await res.json();
    const sel = document.getElementById('script-lead-select');
    if (d.success) {
      sel.innerHTML = '<option value="">Select a lead...</option>' +
        d.data.map(l => `<option value="${l.id}">${escHtml(l.company_name)}</option>`).join('');
    }
  } catch(e) {}
}

function switchChannel(ch, btn) {
  currentChannel = ch;
  document.querySelectorAll('.ch-tab').forEach(t => t.classList.toggle('active', t === btn));
  document.getElementById('script-title').textContent = capitalize(ch) + ' Script';
  if (currentLeadId) loadScript();
}

async function loadScript() {
  const id = document.getElementById('script-lead-select').value;
  if (!id) return;
  currentLeadId = id;
  document.getElementById('script-content').value = 'Loading...';
  try {
    const res = await fetch(`${API}/scripts.php?lead_id=${id}&channel=${currentChannel}`);
    const d = await res.json();
    document.getElementById('script-content').value = d.data?.content || '';
    document.getElementById('script-meta').textContent = d.data ? `Last generated: ${d.data.updated_at || 'Just now'}` : 'No script yet — click Regenerate';
    loadLeadContext(id);
  } catch(e) { document.getElementById('script-content').value = 'Error loading script'; }
}

async function loadLeadContext(id) {
  const lead = allLeads.find(l => l.id == id);
  if (!lead) { try { const r=await fetch(`${API}/leads.php?id=${id}`); const d=await r.json(); if(d.success) renderLeadContext(d.data[0]); } catch(e){} return; }
  renderLeadContext(lead);
}

function renderLeadContext(lead) {
  if (!lead) return;
  document.getElementById('lead-context-content').innerHTML = `
    <div class="context-section"><div class="context-label">Company</div><div class="context-value">${escHtml(lead.company_name||'—')}</div></div>
    <div class="context-section"><div class="context-label">Industry</div><div class="context-value">${escHtml(lead.industry||'—')}</div></div>
    <div class="context-section"><div class="context-label">Products</div><div class="context-value">${escHtml(lead.products||'—')}</div></div>
    <div class="context-section"><div class="context-label">Contact</div><div class="context-value">${escHtml(lead.contact_person||'—')} · ${escHtml(lead.job_profile||'—')}</div></div>
    <div class="context-section"><div class="context-label">Country</div><div class="context-value">${escHtml(lead.country||'—')}</div></div>
    ${lead.scraped_summary?`<div class="context-section"><div class="context-label">Scraped Summary</div><div class="context-value" style="font-size:11px;line-height:1.6">${escHtml(lead.scraped_summary)}</div></div>`:''}
  `;
}

async function regenerateScript() {
  if (!currentLeadId) { showToast('Select a lead first', 'error'); return; }
  document.getElementById('script-content').value = 'Generating with AI...';
  try {
    const res = await fetch(`${API}/generate-script.php`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ lead_id: currentLeadId, channel: currentChannel })
    });
    const d = await res.json();
    if (d.success) { document.getElementById('script-content').value = d.script; showToast('Script generated', 'success'); }
    else { showToast(d.error || 'Generation failed', 'error'); }
  } catch(e) { showToast('Error generating script', 'error'); }
}

async function sendScript() {
  if (!currentLeadId) { showToast('Select a lead first', 'error'); return; }
  const content = document.getElementById('script-content').value.trim();
  if (!content) { showToast('Script is empty', 'error'); return; }
  try {
    const res = await fetch(`${API}/outreach.php`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ lead_ids:[currentLeadId], channel:currentChannel, script:content })
    });
    const d = await res.json();
    showToast(d.message || 'Message sent!', 'success');
  } catch(e) { showToast('Error sending', 'error'); }
}

async function quickSend(id, channel) {
  try {
    const res = await fetch(`${API}/outreach.php`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ lead_ids:[id], channel })
    });
    const d = await res.json();
    showToast(d.message || 'Queued!', 'success');
    loadLeads();
  } catch(e) { showToast('Error', 'error'); }
}

async function generateScript(id) { currentLeadId = id; showPage('scripts'); setTimeout(()=>{ document.getElementById('script-lead-select').value=id; loadScript(); }, 100); }

// ─── Campaigns ──────────────────────────────────────────────────
async function loadCampaigns() {
  try {
    const res = await fetch(`${API}/campaigns.php`);
    const d = await res.json();
    const grid = document.getElementById('campaigns-grid');
    if (!d.success || !d.data.length) { grid.innerHTML = '<div class="card-empty">No campaigns yet. Upload leads to start.</div>'; return; }
    grid.innerHTML = d.data.map(c => `
      <div class="campaign-card">
        <div class="campaign-name">${escHtml(c.name)}</div>
        <div style="font-size:11px;color:var(--text-muted);margin-bottom:10px">${c.created_at}</div>
        <div class="campaign-stats">
          <div class="cstat"><span class="cstat-val">${c.total||0}</span><span class="cstat-lbl">Leads</span></div>
          <div class="cstat"><span class="cstat-val" style="color:var(--blue)">${c.sent||0}</span><span class="cstat-lbl">Sent</span></div>
          <div class="cstat"><span class="cstat-val" style="color:var(--amber)">${c.replied||0}</span><span class="cstat-lbl">Replied</span></div>
          <div class="cstat"><span class="cstat-val" style="color:var(--green)">${c.meetings||0}</span><span class="cstat-lbl">Meetings</span></div>
        </div>
        <div style="display:flex;gap:8px;margin-top:8px">
          <span class="badge ${c.status==='active'?'badge-live':'badge-blue'}">${c.status||'active'}</span>
        </div>
      </div>`).join('');
  } catch(e) {}
}

// ─── Settings ───────────────────────────────────────────────────
async function saveSettings() {
  const payload = {
    claude_api_key: document.getElementById('set-claude').value,
    openai_api_key: document.getElementById('set-openai').value,
    zoho_client_id: document.getElementById('set-zoho-id').value,
    zoho_client_secret: document.getElementById('set-zoho-secret').value,
    wa_api_key: document.getElementById('set-wa').value,
    apify_token: document.getElementById('set-apify').value,
    lusha_api_key: document.getElementById('set-lusha').value,
    from_name: document.getElementById('set-from-name').value,
    from_email: document.getElementById('set-from-email').value,
    reply_to: document.getElementById('set-reply-to').value,
    followup_days: document.getElementById('set-followup-days').value,
    calendly_link: document.getElementById('set-calendly').value,
    company_description: document.getElementById('set-company-desc').value,
    company_usps: document.getElementById('set-usps').value,
  };
  try {
    const res = await fetch(`${API}/settings.php`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });
    const d = await res.json();
    showToast(d.message || 'Settings saved', 'success');
  } catch(e) { showToast('Error saving settings', 'error'); }
}

// ─── Utils ──────────────────────────────────────────────────────
function escHtml(str) {
  if (!str) return '';
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }
function timeAgo(dt) {
  if (!dt) return '';
  const diff = (Date.now() - new Date(dt)) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return Math.floor(diff/60) + 'm ago';
  if (diff < 86400) return Math.floor(diff/3600) + 'h ago';
  return Math.floor(diff/86400) + 'd ago';
}

let toastTimer;
function showToast(msg, type = 'info') {
  const t = document.getElementById('toast');
  t.textContent = msg; t.className = `toast show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.classList.remove('show'); }, 3500);
}

// ─── Init ────────────────────────────────────────────────────────
loadDashboard();
