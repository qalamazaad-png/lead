<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Method not allowed', 405);
if (empty($_FILES['file'])) jsonError('No file uploaded');

$file = $_FILES['file'];
$maxBytes = MAX_UPLOAD_MB * 1024 * 1024;
if ($file['size'] > $maxBytes) jsonError('File too large (max ' . MAX_UPLOAD_MB . 'MB)');

$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if (!in_array($ext, ['xlsx','xls','csv'])) jsonError('Invalid file type. Use .xlsx, .xls or .csv');

// Ensure upload dir
if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
$dest = UPLOAD_DIR . uniqid('import_') . '.' . $ext;
if (!move_uploaded_file($file['tmp_name'], $dest)) jsonError('Failed to save file');

try {
    $spreadsheet = IOFactory::load($dest);
    $sheet = $spreadsheet->getActiveSheet();
    $rows = $sheet->toArray(null, true, true, true);
} catch (Exception $e) {
    unlink($dest);
    jsonError('Could not read file: ' . $e->getMessage());
}

// Column header map (case-insensitive, flexible matching)
$colMap = [
    'company_name'      => ['company name','company','name'],
    'company_website'   => ['company website','website','web','url'],
    'linkedin_page'     => ['linkedin page url','linkedin page','company linkedin'],
    'industry'          => ['nature of business/industry','industry','business type','nature of business'],
    'products'          => ['products','product'],
    'country'           => ['country'],
    'contact_person'    => ['contact person','contact','person','name'],
    'job_profile'       => ['job profile','job title','designation','title'],
    'linkedin_profile'  => ['linkedin profile link','linkedin profile','personal linkedin'],
    'email_a'           => ['email a','email','primary email'],
    'email_b'           => ['email b','secondary email'],
    'contact_a'         => ['contact a','phone','mobile','phone a'],
    'contact_b'         => ['contact b','phone b','mobile b'],
    'whatsapp_link'     => ['whatsapp link','whatsapp','wa'],
    'skype_id'          => ['skype','skype id','skype link'],
];

// Detect header row (first row)
$headerRow = array_shift($rows);
$headers = [];
foreach ($headerRow as $col => $val) {
    if ($val !== null) $headers[$col] = strtolower(trim((string)$val));
}

// Map spreadsheet columns → DB fields
$fieldMap = []; // DB field => spreadsheet column letter
foreach ($colMap as $dbField => $aliases) {
    foreach ($headers as $col => $header) {
        if (in_array($header, $aliases)) { $fieldMap[$dbField] = $col; break; }
    }
}

if (!isset($fieldMap['company_name']) && !isset($fieldMap['email_a'])) {
    unlink($dest);
    jsonError('Could not detect required columns (Company Name or Email A). Check your headers.');
}

$db = getDB();
$inserted = 0; $skipped = 0; $errors = [];
$scrape   = ($_POST['scrape'] ?? '0') === '1';
$generate = ($_POST['generate'] ?? '0') === '1';
$autostart = ($_POST['autostart'] ?? '0') === '1';

$stmt = $db->prepare("
    INSERT INTO leads (company_name, company_website, linkedin_page, industry, products, country,
        contact_person, job_profile, linkedin_profile, email_a, email_b,
        contact_a, contact_b, whatsapp_link, skype_id, status, source_file)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'new',?)
    ON DUPLICATE KEY UPDATE
        company_website = VALUES(company_website),
        linkedin_page   = VALUES(linkedin_page),
        industry        = VALUES(industry),
        products        = VALUES(products),
        country         = VALUES(country),
        contact_person  = VALUES(contact_person),
        job_profile     = VALUES(job_profile),
        linkedin_profile= VALUES(linkedin_profile),
        email_b         = VALUES(email_b),
        contact_a       = VALUES(contact_a),
        contact_b       = VALUES(contact_b),
        whatsapp_link   = VALUES(whatsapp_link),
        skype_id        = VALUES(skype_id)
");

$sourceFile = basename($file['name']);
$importedIds = [];

foreach ($rows as $row) {
    $get = fn($field) => isset($fieldMap[$field]) ? trim((string)($row[$fieldMap[$field]] ?? '')) : '';

    $company = $get('company_name');
    $email   = $get('email_a');
    if (!$company && !$email) { $skipped++; continue; }

    try {
        $stmt->execute([
            $company,
            $get('company_website'),
            $get('linkedin_page'),
            $get('industry'),
            $get('products'),
            $get('country'),
            $get('contact_person'),
            $get('job_profile'),
            $get('linkedin_profile'),
            $email,
            $get('email_b'),
            $get('contact_a'),
            $get('contact_b'),
            $get('whatsapp_link'),
            $get('skype_id'),
            $sourceFile,
        ]);
        $importedIds[] = $db->lastInsertId();
        $inserted++;
    } catch (Exception $e) {
        $errors[] = "Row skipped: " . $e->getMessage();
        $skipped++;
    }
}

// Log activity
$db->prepare("INSERT INTO activity_log (type, message) VALUES ('import', ?)")
   ->execute(["Imported {$inserted} leads from {$sourceFile}"]);

// Queue background jobs
if ($importedIds) {
    if ($scrape) {
        $db->prepare("INSERT INTO activity_log (type, message) VALUES ('job', ?)")
           ->execute(["Scrape queued for " . count($importedIds) . " leads"]);
        // In production, dispatch to job queue — here we save job data to file
        file_put_contents(UPLOAD_DIR . 'scrape_queue.json', json_encode($importedIds));
    }
    if ($generate) {
        file_put_contents(UPLOAD_DIR . 'script_queue.json', json_encode($importedIds));
    }
}

unlink($dest); // clean up temp file

jsonResponse(true, [
    'count'   => $inserted,
    'skipped' => $skipped,
    'errors'  => array_slice($errors, 0, 5),
    'ids'     => array_slice($importedIds, 0, 20),
], "Imported {$inserted} leads" . ($skipped ? ", {$skipped} skipped" : ''));
