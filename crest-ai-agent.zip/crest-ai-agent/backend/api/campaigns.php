<?php
require_once __DIR__ . '/../config/config.php';
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $db->query("
        SELECT c.*, 
            COUNT(DISTINCT l.id) as total,
            SUM(CASE WHEN l.status IN ('contacted','replied','qualified','meeting','closed') THEN 1 ELSE 0 END) as sent,
            SUM(CASE WHEN l.status IN ('replied','qualified','meeting') THEN 1 ELSE 0 END) as replied,
            SUM(CASE WHEN l.status='meeting' THEN 1 ELSE 0 END) as meetings
        FROM campaigns c
        LEFT JOIN leads l ON l.campaign_id = c.id
        GROUP BY c.id
        ORDER BY c.created_at DESC
        LIMIT 50
    ");
    jsonResponse(true, $stmt->fetchAll());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = getRequestBody();
    $name = trim($body['name'] ?? '');
    if (!$name) jsonError('Campaign name required');
    $stmt = $db->prepare("INSERT INTO campaigns (name, description, status) VALUES (?,?,'active')");
    $stmt->execute([$name, $body['description'] ?? '']);
    jsonResponse(true, ['id' => $db->lastInsertId()], 'Campaign created');
}

jsonError('Method not allowed', 405);
