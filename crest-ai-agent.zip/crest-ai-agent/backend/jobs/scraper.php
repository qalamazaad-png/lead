<?php
// ===== WEBSITE SCRAPER JOB =====
// Run via CLI: php scraper.php
// Or trigger via cron: */5 * * * * php /var/www/crest-agent/backend/jobs/scraper.php

require_once __DIR__ . '/../config/config.php';

$queueFile = UPLOAD_DIR . 'scrape_queue.json';
if (!file_exists($queueFile)) { echo "No scrape queue\n"; exit; }

$leadIds = json_decode(file_get_contents($queueFile), true);
if (!$leadIds) { unlink($queueFile); exit; }

$db       = getDB();
$apifyKey = getSetting('apify_token') ?: APIFY_TOKEN;
if (!$apifyKey) { echo "Apify token not configured\n"; exit; }

$processed = 0;
foreach ($leadIds as $i => $leadId) {
    $stmt = $db->prepare('SELECT id, company_website, company_name FROM leads WHERE id = ? AND (scraped_at IS NULL OR company_website IS NOT NULL) LIMIT 1');
    $stmt->execute([$leadId]);
    $lead = $stmt->fetch();

    if (!$lead || !$lead['company_website']) {
        unset($leadIds[$i]);
        continue;
    }

    $url = $lead['company_website'];
    if (!preg_match('/^https?:\/\//', $url)) $url = 'https://' . $url;

    echo "Scraping: {$lead['company_name']} — {$url}\n";

    $summary = scrapeWithApify($url, $apifyKey);
    if ($summary) {
        $db->prepare("UPDATE leads SET scraped_summary = ?, scraped_at = NOW() WHERE id = ?")
           ->execute([substr($summary, 0, 2000), $leadId]);
        $db->prepare("INSERT INTO activity_log (type, message, lead_id) VALUES ('scrape', ?, ?)")
           ->execute(["Website scraped: " . $lead['company_name'], $leadId]);
        echo "  ✓ Scraped\n";
    } else {
        echo "  ✗ Failed\n";
    }

    unset($leadIds[$i]);
    $processed++;
    sleep(2); // polite delay between requests
}

// Rewrite queue with remaining
if ($leadIds) {
    file_put_contents($queueFile, json_encode(array_values($leadIds)));
} else {
    unlink($queueFile);
}
echo "Processed {$processed} leads\n";

// ─── Apify Scrape ──────────────────────────────────────────────
function scrapeWithApify(string $url, string $apiKey): ?string {
    // Start Apify actor run: Website Content Crawler
    $runPayload = [
        'startUrls'   => [['url' => $url]],
        'maxCrawlDepth' => 1,
        'maxCrawlPages' => 3,
        'proxyConfiguration' => ['useApifyProxy' => true],
    ];

    $ch = curl_init('https://api.apify.com/v2/acts/apify~website-content-crawler/runs?token=' . $apiKey . '&waitForFinish=60');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($runPayload),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT        => 90,
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code !== 201 && $code !== 200) return null;

    $run = json_decode($res, true);
    $runId = $run['data']['id'] ?? null;
    if (!$runId) return null;

    // Fetch results
    $resUrl = "https://api.apify.com/v2/actor-runs/{$runId}/dataset/items?token={$apiKey}&limit=5";
    $ch2 = curl_init($resUrl);
    curl_setopt_array($ch2, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 30]);
    $items = json_decode(curl_exec($ch2), true);
    curl_close($ch2);

    if (!$items) return null;

    // Summarise scraped text (first 1500 chars from first few pages)
    $texts = [];
    foreach ($items as $item) {
        $text = $item['text'] ?? $item['markdown'] ?? '';
        if ($text) $texts[] = substr(strip_tags($text), 0, 500);
    }
    return $texts ? implode("\n\n", $texts) : null;
}
