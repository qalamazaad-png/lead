<?php
require_once __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Method not allowed', 405);

$body    = getRequestBody();
$leadId  = (int)($body['lead_id'] ?? 0);
$channel = $body['channel'] ?? 'email';
$type    = $body['type'] ?? 'email1'; // email1 | followup | email2 | email3

if (!$leadId) jsonError('lead_id required');
if (!in_array($channel, ['email','whatsapp','linkedin','skype'])) jsonError('Invalid channel');

$db = getDB();

// Fetch lead
$stmt = $db->prepare('SELECT * FROM leads WHERE id = ? LIMIT 1');
$stmt->execute([$leadId]);
$lead = $stmt->fetch();
if (!$lead) jsonError('Lead not found', 404);

// Settings
$companyDesc = getSetting('company_description', 'Crest Speciality Resins — leading manufacturer of specialty resins for composites and coatings with 30+ years experience.');
$usps        = getSetting('company_usps', '30+ years expertise, Tailor-made resins, ISO certified, International presence');
$fromName    = getSetting('from_name', 'Crest Speciality Resins');
$fromEmail   = getSetting('from_email', 'enquiry@crestresins.com');
$calendly    = getSetting('calendly_link', '');
$apiKey      = getSetting('claude_api_key') ?: CLAUDE_API_KEY;

if (!$apiKey) jsonError('Claude API key not configured. Go to Settings to add it.');

// Build prompt based on channel & type
$leadContext = implode("\n", array_filter([
    "Company: " . ($lead['company_name'] ?? ''),
    "Industry / Business Type: " . ($lead['industry'] ?? 'Unknown'),
    "Their Products: " . ($lead['products'] ?? 'Unknown'),
    "Country: " . ($lead['country'] ?? ''),
    "Contact Person: " . ($lead['contact_person'] ?? 'Decision Maker'),
    "Job Title: " . ($lead['job_profile'] ?? ''),
    $lead['scraped_summary'] ? "Website Summary: " . $lead['scraped_summary'] : '',
]));

$crestContext = "About Crest:\n{$companyDesc}\n\nKey USPs:\n{$usps}";

$prompts = [
    'email' => [
        'email1' => "You are a B2B sales expert for Crest Speciality Resins. Write a personalized cold email to the lead below.

Rules:
- Subject line: compelling, under 10 words, reference their industry
- 3-4 short paragraphs, max 200 words body
- Connect their products/industry to specific Crest resin solutions (Composite Resins for structural/marine/auto, Coating Resins for coil/wood/metal/packaging)
- One specific technical value prop (e.g. fire-retardant, UV-stable, custom viscosity)
- Soft CTA: ask for a 15-minute call or reply with their requirements
- Professional but warm tone — no generic phrases like 'hope this finds you well'
- Sign off as {$fromName}

Format output as:
SUBJECT: [subject line]
---
[email body]",

        'followup' => "Write a follow-up email for a lead who hasn't replied to our first email (sent ~6 days ago).
- Reference that we reached out previously without being pushy
- New angle: mention a specific application relevant to their industry
- Even shorter — max 120 words
- Different CTA: ask a simple yes/no question to trigger a reply
- Same professional warm tone",

        'email2' => "The lead has shown interest. Write Email 2 asking for their technical requirements.
- Thank them for their interest
- Ask about: application (what they're making), substrate/material, operating temperature, required certifications/compliance, annual quantity estimate
- Frame it as 'helping us find the perfect formulation for you'
- Keep it concise — 3 short paragraphs
- End with the meeting/calendly link: {$calendly}",

        'email3' => "The lead has sent their technical requirements. Write a meeting-booking email.
- Confirm we've reviewed their requirements
- Mention we have suitable products (keep vague without specs — for the call)
- Propose 2-3 meeting time options or share Calendly link: {$calendly}
- Express genuine enthusiasm about the potential collaboration
- Max 150 words",
    ],
    'whatsapp' => [
        'email1' => "Write a WhatsApp Business message for cold outreach to this lead.
Rules:
- Max 3 short paragraphs, very conversational
- Start with name if known: 'Hi [Name],' 
- Mention Crest briefly, connect to their industry
- One clear CTA: 'Would you be open to a quick call?'
- Add relevant emoji sparingly (1-2 max)
- NO formal business language — WhatsApp is personal
- End with sender name and company",

        'followup' => "Write a WhatsApp follow-up message (no reply to first message, 6 days later).
- Very short — max 2 lines
- Casual check-in tone
- Simple yes/no question to get a response",
    ],
    'linkedin' => [
        'email1' => "Write a LinkedIn connection request message + first DM for this lead.

CONNECTION REQUEST NOTE (300 chars max):
[Write a personalized note for the connection request]

---
FIRST DM (after connecting):
[Write the first message to send after they accept — 2-3 short paragraphs, conversational, value-focused]",

        'followup' => "Write a LinkedIn follow-up DM (no reply after 7 days).
- Very brief — 2-3 lines
- Reference their recent LinkedIn activity or company news if possible
- One specific question about their resin/material sourcing",
    ],
    'skype' => [
        'email1' => "Write a Skype first message for B2B outreach.
- Brief introduction of Crest
- One sentence on why you're reaching out (their industry connection)
- Propose a quick call
- Max 3-4 sentences, friendly professional tone",
    ],
];

$channelPrompts = $prompts[$channel] ?? $prompts['email'];
$systemPrompt   = $channelPrompts[$type] ?? $channelPrompts['email1'] ?? $channelPrompts[array_key_first($channelPrompts)];

$fullPrompt = "{$crestContext}\n\n---\n\nLEAD DETAILS:\n{$leadContext}\n\n---\n\nINSTRUCTION:\n{$systemPrompt}";

// Call Claude API
$response = callClaude($fullPrompt, $apiKey);
if (!$response['success']) jsonError($response['error']);

$script = $response['content'];

// Save script to DB
$saveSmt = $db->prepare("
    INSERT INTO scripts (lead_id, channel, email_type, content, version)
    VALUES (?, ?, ?, ?, 1)
    ON DUPLICATE KEY UPDATE content = VALUES(content), version = version + 1, updated_at = NOW()
");
$saveSmt->execute([$leadId, $channel, $type, $script]);

// Extract subject if email
$subject = null;
if ($channel === 'email' && preg_match('/^SUBJECT:\s*(.+)$/m', $script, $m)) {
    $subject = trim($m[1]);
    $db->prepare("UPDATE scripts SET subject = ? WHERE lead_id = ? AND channel = ? AND email_type = ?")
       ->execute([$subject, $leadId, $channel, $type]);
}

// Log activity
$db->prepare("INSERT INTO activity_log (type, message, lead_id) VALUES ('script', ?, ?)")
   ->execute(["Script generated ({$channel}/{$type}) for " . ($lead['company_name'] ?? 'Lead'), $leadId]);

jsonResponse(true, ['script' => $script, 'subject' => $subject, 'lead_id' => $leadId, 'channel' => $channel, 'type' => $type], 'Script generated');

// ─── Claude API Call ──────────────────────────────────────────────
function callClaude(string $prompt, string $apiKey): array {
    $payload = [
        'model'      => 'claude-sonnet-4-20250514',
        'max_tokens' => 800,
        'messages'   => [['role' => 'user', 'content' => $prompt]],
    ];

    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'x-api-key: ' . $apiKey,
            'anthropic-version: 2023-06-01',
        ],
        CURLOPT_TIMEOUT        => 30,
    ]);

    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($err) return ['success' => false, 'error' => 'cURL error: ' . $err];
    $data = json_decode($res, true);
    if ($code !== 200) return ['success' => false, 'error' => $data['error']['message'] ?? 'API error ' . $code];

    $content = $data['content'][0]['text'] ?? '';
    if (!$content) return ['success' => false, 'error' => 'Empty response from Claude'];

    return ['success' => true, 'content' => $content];
}
