# Crest AI Outreach Agent

AI-powered B2B outreach automation for Crest Speciality Resins.
Handles Email, WhatsApp, LinkedIn, and Skype outreach with Claude AI script generation.

---

## Project Structure

```
crest-ai-agent/
├── frontend/
│   ├── index.html          ← Single-page dashboard
│   ├── css/style.css       ← All styles
│   └── js/app.js           ← Frontend logic
├── backend/
│   ├── config/
│   │   ├── config.php      ← DB + helpers (edit DB credentials here)
│   │   └── schema.sql      ← Run once to create all tables
│   ├── api/
│   │   ├── leads.php       ← GET/PUT/DELETE leads
│   │   ├── import.php      ← POST Excel file → import leads
│   │   ├── generate-script.php  ← POST → AI script via Claude
│   │   ├── outreach.php    ← POST → send Email/WA/LinkedIn/Skype
│   │   ├── scripts.php     ← GET saved scripts
│   │   ├── stats.php       ← GET dashboard counts
│   │   ├── activity.php    ← GET activity feed
│   │   ├── campaigns.php   ← GET/POST campaigns
│   │   └── settings.php    ← GET/POST API keys & config
│   └── jobs/
│       ├── scraper.php     ← Apify website scraper (cron)
│       ├── followup.php    ← Auto follow-up emails (cron daily)
│       └── reply-analyser.php  ← Zoho inbox reply parser (cron 30min)
├── nginx/
│   └── crest-agent.conf    ← Nginx virtual host config
├── composer.json           ← PHP dependencies
├── setup.sh                ← One-command VPS setup
└── .env.example            ← Copy to .env and fill values
```

---

## Quick Deploy (VPS — Ubuntu 22.04 / 24.04)

```bash
# 1. SSH into your VPS
ssh root@YOUR_SERVER_IP

# 2. Upload project files
scp -r crest-ai-agent/ root@YOUR_SERVER_IP:/root/

# 3. Run setup script
cd /root/crest-ai-agent
bash setup.sh yourdomain.com
```

The script installs Nginx, PHP 8.2, MySQL, Composer, SSL certificate,
creates the database, sets up cron jobs, and configures the firewall.

---

## Manual Setup (step by step)

### 1. Install requirements
```bash
apt-get update && apt-get install -y nginx mysql-server php8.2 php8.2-fpm \
  php8.2-mysql php8.2-curl php8.2-mbstring php8.2-xml php8.2-zip \
  certbot python3-certbot-nginx composer
```

### 2. Database
```bash
mysql -e "CREATE DATABASE crest_agent CHARACTER SET utf8mb4;"
mysql -e "CREATE USER 'crest_user'@'localhost' IDENTIFIED BY 'YOURPASSWORD';"
mysql -e "GRANT ALL ON crest_agent.* TO 'crest_user'@'localhost';"
mysql -u crest_user -p crest_agent < backend/config/schema.sql
```

### 3. Edit config
```bash
nano backend/config/config.php
# Set DB_HOST, DB_NAME, DB_USER, DB_PASS
# Set APP_URL to your domain
```

### 4. PHP dependencies
```bash
composer install --no-dev --optimize-autoloader
```

### 5. App directory
```bash
cp -r . /var/www/crest-agent
mkdir -p /var/www/crest-agent/uploads
chown -R www-data:www-data /var/www/crest-agent
chmod -R 775 /var/www/crest-agent/uploads
```

### 6. Nginx
```bash
# Edit domain in nginx config
sed -i 's/yourdomain.com/YOURDOMAIN.COM/g' nginx/crest-agent.conf
cp nginx/crest-agent.conf /etc/nginx/sites-available/crest-agent
ln -s /etc/nginx/sites-available/crest-agent /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

### 7. SSL
```bash
certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

### 8. Cron jobs
```bash
crontab -e
# Add these lines:
0 9 * * *     php /var/www/crest-agent/backend/jobs/followup.php >> /var/www/crest-agent/logs/followup.log 2>&1
*/30 * * * *  php /var/www/crest-agent/backend/jobs/reply-analyser.php >> /var/www/crest-agent/logs/replies.log 2>&1
*/5 * * * *   php /var/www/crest-agent/backend/jobs/scraper.php >> /var/www/crest-agent/logs/scraper.log 2>&1
```

---

## First Run

1. Open `https://yourdomain.com`
2. Go to **Settings** and enter:
   - Claude API key (`sk-ant-...`)
   - Zoho email credentials (SMTP password + OAuth tokens)
   - WhatsApp 360dialog API key
   - Apify API token
   - Lusha API key
   - Calendly meeting link
3. Go to **Upload Leads** and upload your Excel file
4. Leads appear in the **Leads** tab
5. Select leads → **Send Email** or go to **Scripts** tab to review AI-generated messages first

---

## Excel Format

Your Excel file should have these column headers (exact match or close):

| Column | Required |
|--------|----------|
| Company Name | ✓ |
| Email A | ✓ |
| Company Website | |
| LinkedIn Page URL | |
| Nature of Business/Industry | |
| Products | |
| Country | |
| Contact Person | |
| Job Profile | |
| LinkedIn Profile Link | |
| Email B | |
| Contact A | |
| Contact B | |
| WhatsApp Link | |
| Skype | |

---

## Automated Workflow

```
Upload Excel
    ↓
Apify scrapes each lead's website (every 5 min)
    ↓
Claude generates personalised scripts (Email/WA/LinkedIn/Skype)
    ↓
Email 1 sent via Zoho
    ↓
No reply after 6 days → Follow-up email auto-sent
    ↓
Reply received → Claude classifies intent
    ├── Interested → Email 2 sent (technical questions)
    ├── Tech specs received → Email 3 sent (meeting invite + Calendly)
    └── Not interested → Lead marked Closed
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/leads.php | List all leads |
| PUT | /api/leads.php | Update lead |
| DELETE | /api/leads.php | Delete lead |
| POST | /api/import.php | Upload Excel |
| POST | /api/generate-script.php | Generate AI script |
| POST | /api/outreach.php | Send outreach |
| GET | /api/scripts.php | Get saved script |
| GET | /api/stats.php | Dashboard counts |
| GET | /api/activity.php | Activity feed |
| GET/POST | /api/settings.php | App settings |
| GET/POST | /api/campaigns.php | Campaigns |

---

## WhatsApp Setup (360dialog)

1. Sign up at https://www.360dialog.com
2. Connect your WhatsApp Business number
3. Get your API key from dashboard
4. Enter in Settings → WhatsApp API Key

## Zoho Email Setup

1. In Zoho Mail: Settings → Security → App Passwords → Generate
2. Enter that password in Settings → Zoho SMTP Password
3. From email must match your Zoho account email

## Apify Setup

1. Sign up at https://apify.com
2. Go to Settings → Integrations → API tokens
3. Copy token → Settings → Apify Token

---

## Security Notes

- API keys are stored in the `settings` database table, encrypted in transit
- The `.env` file and `uploads/` directory are blocked by Nginx
- Never commit real API keys to git (`.gitignore` covers `.env`)
- Database password is only in `.env` and `config.php` on the server
