<?php
// ===== CREST AI AGENT — BACKEND CONFIG =====
// Copy this file and fill all values. NEVER commit real keys to git.

define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'crest_agent');
define('DB_USER', getenv('DB_USER') ?: 'crest_user');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_CHARSET', 'utf8mb4');

define('APP_URL', getenv('APP_URL') ?: 'https://yourdomain.com');
define('APP_ENV', getenv('APP_ENV') ?: 'production'); // production | development

// API keys loaded from DB settings table (set via /api/settings.php)
// These are fallback env-based values for initial bootstrap
define('CLAUDE_API_KEY',  getenv('CLAUDE_API_KEY')  ?: '');
define('OPENAI_API_KEY',  getenv('OPENAI_API_KEY')  ?: '');
define('APIFY_TOKEN',     getenv('APIFY_TOKEN')     ?: '');
define('LUSHA_API_KEY',   getenv('LUSHA_API_KEY')   ?: '');
define('WA_API_KEY',      getenv('WA_API_KEY')      ?: '');
define('ZOHO_CLIENT_ID',  getenv('ZOHO_CLIENT_ID')  ?: '');
define('ZOHO_CLIENT_SECRET', getenv('ZOHO_CLIENT_SECRET') ?: '');

// Upload settings
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_UPLOAD_MB', 10);

function getDB(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    return $pdo;
}

function getSetting(string $key, string $default = ''): string {
    try {
        $db = getDB();
        $stmt = $db->prepare('SELECT value FROM settings WHERE `key` = ? LIMIT 1');
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        return $row ? $row['value'] : $default;
    } catch (Exception $e) { return $default; }
}

function jsonResponse(bool $success, $data = null, string $message = '', int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode(['success' => $success, 'message' => $message, 'data' => $data]);
    exit;
}

function jsonError(string $msg, int $code = 400): void {
    jsonResponse(false, null, $msg, $code);
}

function corsHeaders(): void {
    $origin = APP_ENV === 'development' ? '*' : APP_URL;
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
}

function getRequestBody(): array {
    $raw = file_get_contents('php://input');
    return json_decode($raw, true) ?: [];
}

corsHeaders();
