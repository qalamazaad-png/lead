<?php
require_once __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Method not allowed', 405);

$body    = getRequestBody();
$leadIds = $body['lead_ids'] ?? [];
$channel = $body['channel'] ?? 'email';
$script  = $body['script'] ?? null; // optional override script
$type    = $body['type'] ?? 'email1';

if (empty($leadIds)) jsonError('lead_ids required');
if (!in_array($channel, ['email','whatsapp','linkedin','skype'])) jsonError('Invalid channel');

$db = getDB();
$sent = 0; $failed = 0; $results = [];

foreach ($leadIds as $leadId) {
    $leadId = (int)$leadId;
    $stmt = $db->prepare('SELECT * FROM leads WHERE id = ? LIMIT 1');
    $stmt->execute([$leadId]);
    $lead = $stmt->fetch();
    if (!$lead) { $failed++; continue; }

    // Get or use provided script
    $content = $script;
    $subject = null;
    if (!$content) {
        $sStmt = $db->prepare('SELECT content, subject FROM scripts WHERE lead_id = ? AND channel = ? AND email_type = ? ORDER BY version DESC LIMIT 1');
        $sStmt->execute([$leadId, $channel, $type]);
        $scriptRow = $sStmt->fetch();
        $content = $scriptRow['content'] ?? null;
        $subject = $scriptRow['subject'] ?? null;
    }

    if (!$content) {
        // Auto-generate script first
        $genRes = generateScriptForLead($leadId, $channel, $type);
        if (!$genRes['success']) { $failed++; $results[] = ['id'=>$leadId,'error'=>'No script found and generation failed']; continue; }
        $content = $genRes['script'];
        $subject = $genRes['subject'] ?? null;
    }

    // Dispatch by channel
    $result = match($channel) {
        'email'     => sendEmail($lead, $content, $subject, $type),
        'whatsapp'  => sendWhatsApp($lead, $content),
        'linkedin'  => queueLinkedIn($lead, $content),
        'skype'     => sendSkype($lead, $content),
        default     => ['success' => false, 'error' => 'Unknown channel'],
    };

    // Log outreach
    $logStmt = $db->prepare("INSERT INTO outreach_log (lead_id, channel, email_type, direction, status, subject, content, external_id, sent_at) VALUES (?,?,?,'sent',?,?,?,?,NOW())");
    $logStmt->execute([
        $leadId, $channel, $type,
        $result['success'] ? 'sent' : 'failed',
        $subject, $content,
        $result['external_id'] ?? null,
    ]);

    if ($result['success']) {
        // Update lead status
        $newStatus = $lead['status'] === 'new' ? 'contacted' : $lead['status'];
        $db->prepare("UPDATE leads SET status = ? WHERE id = ?")->execute([$newStatus, $leadId]);

        // Activity log
        $db->prepare("INSERT INTO activity_log (type, message, lead_id) VALUES (?,?,?)")
           ->execute([$channel, ucfirst($channel) . " sent to " . ($lead['company_name'] ?? 'lead'), $leadId]);
        $sent++;
    } else {
        $db->prepare("UPDATE outreach_log SET status='failed', error_message=? WHERE lead_id=? AND channel=? ORDER BY id DESC LIMIT 1")
           ->execute([$result['error'] ?? 'Unknown error', $leadId, $channel]);
        $failed++;
        $results[] = ['id' => $leadId, 'error' => $result['error'] ?? 'Send failed'];
    }
}

jsonResponse(true, ['sent' => $sent, 'failed' => $failed, 'details' => $results],
    "{$sent} message(s) sent" . ($failed ? ", {$failed} failed" : ''));


// ─── Email via Zoho SMTP ────────────────────────────────────────
function sendEmail(array $lead, string $content, ?string $subject, string $type): array {
    $email = $lead['email_a'] ?? '';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return ['success'=>false,'error'=>'Invalid email address'];

    $fromName   = getSetting('from_name', 'Crest Speciality Resins');
    $fromEmail  = getSetting('from_email', 'enquiry@crestresins.com');
    $replyTo    = getSetting('reply_to', $fromEmail);

    // Strip SUBJECT: line from body if present
    $body = preg_replace('/^SUBJECT:.*$/m', '', $content);
    $body = trim($body, "\n -");
    if (!$subject) {
        preg_match('/^SUBJECT:\s*(.+)$/m', $content, $m);
        $subject = $m[1] ?? 'Specialty Resins — Crest Speciality Resins';
    }

    // Use Zoho SMTP via PHPMailer
    try {
        require_once __DIR__ . '/../../vendor/autoload.php';
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = 'smtp.zoho.in';
        $mail->SMTPAuth   = true;
        $mail->Username   = getSetting('from_email');
        $mail->Password   = getSetting('zoho_smtp_password'); // SMTP password (not OAuth)
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->setFrom($fromEmail, $fromName);
        $mail->addAddress($email, $lead['contact_person'] ?? '');
        $mail->addReplyTo($replyTo, $fromName);
        $mail->Subject = $subject;
        $mail->Body    = nl2br(htmlspecialchars($body));
        $mail->AltBody = $body;
        $mail->isHTML(true);
        $mail->send();
        return ['success' => true, 'external_id' => null];
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

// ─── WhatsApp via 360dialog ────────────────────────────────────
function sendWhatsApp(array $lead, string $content): array {
    $waLink = $lead['whatsapp_link'] ?? $lead['contact_a'] ?? '';
    // Extract phone number from WhatsApp link or direct number
    $phone = preg_replace('/[^0-9]/', '', $waLink);
    if (strlen($phone) < 10) return ['success'=>false,'error'=>'No valid WhatsApp number'];

    // Add country code if needed
    if (strlen($phone) === 10) $phone = '91' . $phone; // default India

    $apiKey = getSetting('wa_api_key') ?: WA_API_KEY;
    if (!$apiKey) return ['success'=>false,'error'=>'WhatsApp API key not configured'];

    $payload = ['to' => $phone, 'type' => 'text', 'text' => ['body' => $content]];
    $ch = curl_init('https://waba.360dialog.io/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'D360-API-KEY: ' . $apiKey],
        CURLOPT_TIMEOUT        => 15,
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $data = json_decode($res, true);
    if ($code === 200 || $code === 201) return ['success' => true, 'external_id' => $data['messages'][0]['id'] ?? null];
    return ['success' => false, 'error' => $data['meta']['developer_message'] ?? 'WA send failed'];
}

// ─── LinkedIn (queue for manual/Lusha) ────────────────────────
function queueLinkedIn(array $lead, string $content): array {
    // LinkedIn automation requires Lusha or PhantomBuster
    // Here we queue it and mark as 'queued' — manual action or Lusha API
    $lushKey = getSetting('lusha_api_key') ?: LUSHA_API_KEY;
    if (!$lushKey) return ['success'=>false,'error'=>'Lusha API key not configured — LinkedIn outreach queued for manual send'];

    // Log to queue file (integrate Lusha/PhantomBuster here)
    $queueFile = UPLOAD_DIR . 'linkedin_queue.json';
    $queue = file_exists($queueFile) ? json_decode(file_get_contents($queueFile), true) : [];
    $queue[] = ['lead_id'=>$lead['id'], 'linkedin'=>$lead['linkedin_profile'], 'message'=>$content, 'queued_at'=>date('c')];
    file_put_contents($queueFile, json_encode($queue));

    return ['success' => true, 'external_id' => 'queued'];
}

// ─── Skype ─────────────────────────────────────────────────────
function sendSkype(array $lead, string $content): array {
    $skypeId = $lead['skype_id'] ?? '';
    if (!$skypeId) return ['success'=>false,'error'=>'No Skype ID for this lead'];

    // Skype Bot API (Microsoft Azure Bot Service)
    // Queue for now — full integration requires Azure Bot registration
    $queueFile = UPLOAD_DIR . 'skype_queue.json';
    $queue = file_exists($queueFile) ? json_decode(file_get_contents($queueFile), true) : [];
    $queue[] = ['lead_id'=>$lead['id'], 'skype_id'=>$skypeId, 'message'=>$content, 'queued_at'=>date('c')];
    file_put_contents($queueFile, json_encode($queue));

    return ['success' => true, 'external_id' => 'queued_skype'];
}

// ─── Auto generate script helper ───────────────────────────────
function generateScriptForLead(int $leadId, string $channel, string $type): array {
    $apiUrl = APP_URL . '/api/generate-script.php';
    $ch = curl_init($apiUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode(['lead_id'=>$leadId,'channel'=>$channel,'type'=>$type]),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT        => 45,
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($res, true);
    return $data['success'] ? ['success'=>true,'script'=>$data['data']['script'],'subject'=>$data['data']['subject']] : ['success'=>false,'error'=>$data['message']??'Generation failed'];
}
