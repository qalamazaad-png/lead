<?php
// ===== FOLLOW-UP SCHEDULER =====
// Run via cron daily: 0 9 * * * php /var/www/crest-agent/backend/jobs/followup.php

require_once __DIR__ . '/../config/config.php';

$db          = getDB();
$followupDays = (int)getSetting('followup_days', '6');

// Find leads contacted > N days ago with no reply
$stmt = $db->prepare("
    SELECT l.id, l.company_name, l.email_a, l.status,
           MAX(ol.sent_at) as last_sent,
           ol.email_type as last_type
    FROM leads l
    JOIN outreach_log ol ON ol.lead_id = l.id AND ol.channel = 'email' AND ol.direction = 'sent'
    WHERE l.status = 'contacted'
      AND l.email_a IS NOT NULL
      AND ol.email_type = 'email1'
    GROUP BY l.id
    HAVING last_sent < DATE_SUB(NOW(), INTERVAL ? DAY)
    LIMIT 50
");
$stmt->execute([$followupDays]);
$dueleads = $stmt->fetchAll();

echo date('Y-m-d H:i:s') . " — Follow-up check: " . count($dueleads) . " leads due\n";

$sent = 0;
foreach ($dueleads as $lead) {
    echo "  Following up: {$lead['company_name']} (last sent: {$lead['last_sent']})\n";

    // Generate follow-up script
    $genCh = curl_init(APP_URL . '/api/generate-script.php');
    curl_setopt_array($genCh, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode(['lead_id'=>$lead['id'],'channel'=>'email','type'=>'followup']),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT        => 45,
    ]);
    $genRes = json_decode(curl_exec($genCh), true);
    curl_close($genCh);

    if (!($genRes['success'] ?? false)) { echo "    ✗ Script generation failed\n"; continue; }

    // Send follow-up
    $sendCh = curl_init(APP_URL . '/api/outreach.php');
    curl_setopt_array($sendCh, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode(['lead_ids'=>[$lead['id']],'channel'=>'email','type'=>'followup']),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT        => 30,
    ]);
    $sendRes = json_decode(curl_exec($sendCh), true);
    curl_close($sendCh);

    if ($sendRes['data']['sent'] ?? 0) {
        $db->prepare("INSERT INTO activity_log (type, message, lead_id) VALUES ('followup', ?, ?)")
           ->execute(["Follow-up email sent to {$lead['company_name']}", $lead['id']]);
        $sent++;
        echo "    ✓ Sent\n";
    } else {
        echo "    ✗ Send failed: " . ($sendRes['message'] ?? 'unknown') . "\n";
    }
    sleep(2);
}

echo "Done. Sent {$sent} follow-ups.\n";
